import numpy as np
import matplotlib.pyplot as plt

x = np.arange(0,10.1,0.1)
y = np.sin(x)

plt.figure()
plt.plot(x, y, color = 'r', label = 'y = sin(x)')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.savefig('test.png')